(() => {
var exports = {};
exports.id = 931;
exports.ids = [931];
exports.modules = {

/***/ 8038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 8704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 7897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 6786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 5868:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/app-render");

/***/ }),

/***/ 1844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 6624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 5281:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/route-modules/route-module");

/***/ }),

/***/ 7085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 1830:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/get-img-props");

/***/ }),

/***/ 199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 6864:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head");

/***/ }),

/***/ 9569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 2210:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config");

/***/ }),

/***/ 5359:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context");

/***/ }),

/***/ 7160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 2336:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url");

/***/ }),

/***/ 7887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 8735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 120:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url");

/***/ }),

/***/ 8231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 4614:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix");

/***/ }),

/***/ 3750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 982:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href");

/***/ }),

/***/ 9618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 8423:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils");

/***/ }),

/***/ 8658:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once");

/***/ }),

/***/ 1017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 7310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 1853:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   routeModule: () => (/* binding */ routeModule),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7262);
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9513);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1823);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2502);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);
// @ts-ignore this need to be imported from next/dist to be external


const AppPageRouteModule = next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__.AppPageRouteModule;
// We inject the tree and pages here so that we can use them in the route
// module.
const tree = {
        children: [
        '',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 378)), "E:\\anbareomomi\\app\\page.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 7481))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }]
      },
        {
        'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 7547)), "E:\\anbareomomi\\app\\layout.tsx"],
'not-found': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 5493, 23)), "next/dist/client/components/not-found-error"],
        metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 7481))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
      }
      ]
      }.children;
const pages = ["E:\\anbareomomi\\app\\page.tsx"];

// @ts-expect-error - replaced by webpack/turbopack loader

const __next_app_require__ = __webpack_require__
const __next_app_load_chunk__ = () => Promise.resolve()
const originalPathname = "/page";
const __next_app__ = {
    require: __next_app_require__,
    loadChunk: __next_app_load_chunk__
};

// Create and export the route module that will be consumed.
const routeModule = new AppPageRouteModule({
    definition: {
        kind: next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__.RouteKind.APP_PAGE,
        page: "/page",
        pathname: "/",
        // The following aren't used in production.
        bundlePath: "",
        filename: "",
        appPaths: []
    },
    userland: {
        loaderTree: tree
    }
});

//# sourceMappingURL=app-page.js.map

/***/ }),

/***/ 229:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 3380, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 954, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 9857));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 8057))

/***/ }),

/***/ 8057:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var modularize_import_loader_name_Disclosure_join_components_disclosure_disclosure_headlessui_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1578);
/* harmony import */ var modularize_import_loader_name_Transition_join_components_transitions_transition_headlessui_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1195);
/* __next_internal_client_entry_do_not_use__ default auto */ 


function DisclosureFeatures() {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "flex gap-3 flex-col w-full",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(modularize_import_loader_name_Disclosure_join_components_disclosure_disclosure_headlessui_react__WEBPACK_IMPORTED_MODULE_1__/* .Disclosure */ .p, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(modularize_import_loader_name_Disclosure_join_components_disclosure_disclosure_headlessui_react__WEBPACK_IMPORTED_MODULE_1__/* .Disclosure */ .p.Button, {
                        className: "py-2 px-3 w-full bg-secondary hover:bg-primary text-white hover:text-secondary transition-colors rounded-lg shadow-lg",
                        children: "نگهداری اموال توقیفی"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(modularize_import_loader_name_Transition_join_components_transitions_transition_headlessui_react__WEBPACK_IMPORTED_MODULE_2__/* .Transition */ .u, {
                        enter: "transition duration-100 ease-out",
                        enterFrom: "transform scale-95 opacity-0",
                        enterTo: "transform scale-100 opacity-100",
                        leave: "transition duration-75 ease-out",
                        leaveFrom: "transform scale-100 opacity-100",
                        leaveTo: "transform scale-95 opacity-0",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(modularize_import_loader_name_Disclosure_join_components_disclosure_disclosure_headlessui_react__WEBPACK_IMPORTED_MODULE_1__/* .Disclosure */ .p.Panel, {
                            className: "text-gray-500 py-5",
                            children: "آیا میدانید اگر از شخصی مطالبه دارید مطابق قانون اجرا اموال تا زمان مزایده باید به امین اموال معتبر و فضای امن سپرده شود ؟ لذا با عقد قرارداد با ما میتوانید اموال توقیفی محکوم علیه را به ما بسپارید زیرا که ما امین اموال معتبر و مورد قبول دادگستری هستیم."
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(modularize_import_loader_name_Disclosure_join_components_disclosure_disclosure_headlessui_react__WEBPACK_IMPORTED_MODULE_1__/* .Disclosure */ .p, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(modularize_import_loader_name_Disclosure_join_components_disclosure_disclosure_headlessui_react__WEBPACK_IMPORTED_MODULE_1__/* .Disclosure */ .p.Button, {
                        className: "py-2 px-3 w-full bg-secondary hover:bg-primary text-white hover:text-secondary transition-colors rounded-lg shadow-lg",
                        children: "نگهداری جهیزیه"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(modularize_import_loader_name_Transition_join_components_transitions_transition_headlessui_react__WEBPACK_IMPORTED_MODULE_2__/* .Transition */ .u, {
                        enter: "transition duration-100 ease-out",
                        enterFrom: "transform scale-95 opacity-0",
                        enterTo: "transform scale-100 opacity-100",
                        leave: "transition duration-75 ease-out",
                        leaveFrom: "transform scale-100 opacity-100",
                        leaveTo: "transform scale-95 opacity-0",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(modularize_import_loader_name_Disclosure_join_components_disclosure_disclosure_headlessui_react__WEBPACK_IMPORTED_MODULE_1__/* .Disclosure */ .p.Panel, {
                            className: "text-gray-500 py-5",
                            children: "اگر برای نگهداری جهیزیه خود نیازمند فضای امن و مناسب هستید میتوانید آن را به انبار کانتینریه آرتا بسپارید."
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(modularize_import_loader_name_Disclosure_join_components_disclosure_disclosure_headlessui_react__WEBPACK_IMPORTED_MODULE_1__/* .Disclosure */ .p, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(modularize_import_loader_name_Disclosure_join_components_disclosure_disclosure_headlessui_react__WEBPACK_IMPORTED_MODULE_1__/* .Disclosure */ .p.Button, {
                        className: "py-2 px-3 w-full bg-secondary hover:bg-primary text-white hover:text-secondary transition-colors rounded-lg shadow-lg",
                        children: "نگهداری کالا های تجاری"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(modularize_import_loader_name_Transition_join_components_transitions_transition_headlessui_react__WEBPACK_IMPORTED_MODULE_2__/* .Transition */ .u, {
                        enter: "transition duration-100 ease-out",
                        enterFrom: "transform scale-95 opacity-0",
                        enterTo: "transform scale-100 opacity-100",
                        leave: "transition duration-75 ease-out",
                        leaveFrom: "transform scale-100 opacity-100",
                        leaveTo: "transform scale-95 opacity-0",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(modularize_import_loader_name_Disclosure_join_components_disclosure_disclosure_headlessui_react__WEBPACK_IMPORTED_MODULE_1__/* .Disclosure */ .p.Panel, {
                            className: "text-gray-500 py-5",
                            children: "قابل توجه وارد کنندگان و صادر کنندگان و توزیع کنندگان نگهداری انواع کالا تجاری در انبارهای مسقف و کانتینر های ما با نازلترین قیمت ها بصورت شبانه روزی با پرسنل مجرب و تجهیزات تخلیه و بارگیری و حمل و نقل در مقابل گمرک غرب تهران"
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(modularize_import_loader_name_Disclosure_join_components_disclosure_disclosure_headlessui_react__WEBPACK_IMPORTED_MODULE_1__/* .Disclosure */ .p, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(modularize_import_loader_name_Disclosure_join_components_disclosure_disclosure_headlessui_react__WEBPACK_IMPORTED_MODULE_1__/* .Disclosure */ .p.Button, {
                        className: "py-2 px-3 w-full bg-secondary hover:bg-primary text-white hover:text-secondary transition-colors rounded-lg shadow-lg",
                        children: "توزیع کننده مویرگی و بنکداران عزیز"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(modularize_import_loader_name_Transition_join_components_transitions_transition_headlessui_react__WEBPACK_IMPORTED_MODULE_2__/* .Transition */ .u, {
                        enter: "transition duration-100 ease-out",
                        enterFrom: "transform scale-95 opacity-0",
                        enterTo: "transform scale-100 opacity-100",
                        leave: "transition duration-75 ease-out",
                        leaveFrom: "transform scale-100 opacity-100",
                        leaveTo: "transform scale-95 opacity-0",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(modularize_import_loader_name_Disclosure_join_components_disclosure_disclosure_headlessui_react__WEBPACK_IMPORTED_MODULE_1__/* .Disclosure */ .p.Panel, {
                            className: "text-gray-500 py-5",
                            children: "آیا میدانید در انبار کانتینری آرتا میتوانید با داشتن چند کانتینر یا انبار مسقف با فضای مناسب دفتری و تجهیزات اداری کاملا مبله و با تجهیزات تخلیه و بارگیری و حمل و نقل با دسترسی خوب خ فتح و اتوبان آزادگان کاملا بدون نگرانی کالاهای خود را توزیع نمایید ."
                        })
                    })
                ]
            })
        ]
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (DisclosureFeatures);


/***/ }),

/***/ 378:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Home)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(4178);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(5124);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./Components/Shared/BigButton.tsx


function BigButton({ minWidth, color }) {
    return /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
        href: "tel:+9821912031682",
        className: `${minWidth ? "" : "w-full"} ${color ? color : "bg-secondary text-textColor"} rounded-full   flex justify-center items-center py-3 px-5`,
        children: "همین حالا انبارتو بگیر!"
    });
}

;// CONCATENATED MODULE: ./Components/Home/Hero.tsx




function Hero() {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        className: "w-full overflow-y-visible flex justify-start items-start flex-col relative lg:h-[75%] mb-20",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "overflow-hidden w-full h-[70%] lg:min-h-auto min-h-[500px] relative",
                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                    src: "/assets/Images/Hero.jpg",
                    alt: "plant background",
                    layout: "fill",
                    objectFit: "cover",
                    priority: true
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex justify-center items-center gap-7 flex-col py-5 md:absolute top-0 h-[110%] right-[7%] text-secondary lg:text-textColor px-10 md:w-[470px] xl:w-[550px] w-full",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: `text-4xl  font-semibold font-IranSans`,
                        children: [
                            "انبار های زنجیره ای آرتا",
                            " "
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: `text-md font-light px-2 font-IranSans text-justify `,
                        children: "۲۵هزار متر مربع سوله , ۱۵۰۰ دستگاه کانتینر , ۱۵۰ هزار متر انبار روباز , ۲۰۰۰ متر سردخانه , ۱۰ دستگاه کامیونت و لیفتراک , ۵۰ نفر پرسنل مجرب آموزش دیده , ۳۰نفر نگهبان موسسه حفاظتی نیروی انتظامی"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(BigButton, {
                        color: "bg-primary text-secondary"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "top-[25%] md:top-auto md:bottom-[10%] left-[7%] absolute z-1 flex flex-col gap-1 font-bold md:text-2xl text-3xl  lg:text-4xl"
            })
        ]
    });
}

;// CONCATENATED MODULE: ./Components/Home/TopCategories.tsx



async function TopCategories() {
    const popularCategories = [
        {
            image: "/assets/Images/Services/1.jpg",
            id: "1",
            title: "اجاره انبار کانتینری",
            content: "با انبار های کانتینری کالاهای خود را در امن ترین شرایط نگهداری کنید،انبار های کانتینری ارزان ترین و ایزوله و امن ترین محیط برای نگهداری انواع کالا و اثاثیه شما میباشد"
        },
        {
            image: "/assets/Images/Services/saderat.jpg",
            id: "1",
            title: "صادرات اثاثیه",
            content: "صادرات اثاثیه به سراسر جهان ، آماده ارائه خدمات بسته بندی اثاث حمل تا گمرک و صادرات آن به تمامی کشور ها ، با استفاده از معتبرترین کشتیرانی های جهان در کوتاه ترین زمان"
        },
        {
            image: "/assets/Images/Services/car.jpg",
            id: "1",
            title: "پارکینگ خودرو های لوکس",
            content: "اگر مسافر هستید خودرو گران قیمت خود را به ما بسپارید،ضد زلزله ضد سرقت ضد آتش سوزی ،نگهداری خودرو در کانتیر های ایزوله تخصص ماست"
        },
        {
            image: "/assets/Images/Services/toghifi.jpg",
            id: "1",
            title: "نگهداری اموال توقیفی",
            content: "آیا میدانید اگر از شخصی مطالبه ای دارید یا حکم تخلیه ملکی دارید مطابق قانون اجرا اموال تا زمان مزایده باید به امین اموال معتبر و فضای امن سپرده شود لذا با عقد قرارداد با ما میتوانید اموال توقیفی محکوم علیه را به ما بسپارید زیرا که ما امین اموال معتبر و مورد قبول دادگستری هستیم"
        },
        {
            image: "/assets/Images/Services/sandogh.jpg",
            id: "1",
            title: "صندوق امانی انبار کانتینری",
            content: "درصندوق امانی گاوصندوق دیجیتالی ما نصب شده در کانتینر اختصاصی شما صندوق ضد زلزله ضد سرقت و ضد آتش سوزی محیط امنی برای نگهداری اسناد محرمانه شما میباشد ،کلیه صندوق های امانی تحت ضمانت بانک پارسیان ،زیر پوشش بیمه ایران می باشد"
        },
        {
            image: "/assets/Images/Services/negahdai-asasie.jpg",
            id: "1",
            title: "نگهداری اثاثیه",
            content: "پایتخت ایران تهران هر لحظه در تهدید زلزله شدید می باشد، اگر مسافر هستید اثاثیه منزل خود را در صندوق ضد زلزله، ضد آتش سوزی و ضد سرقت ما با کمترین هزینه و بدون هیچ گونه نگرانی تحت پوشش بیمه ایران و تحت ضمانت بانک پارسیان قرار دهید"
        },
        {
            image: "/assets/Images/Services/asasie.png",
            id: "1",
            title: "بسته بندی اثاثیه",
            content: "شرکت آرتا با بهره گیری از بهترین تجهیزات و مجرب ترین پرسنل با کمترین هزینه اثاثیه یا سایر کالاهای شما را بسته بندی و به انبار های آرتا انتقال می دهد"
        },
        {
            image: "/assets/Images/Services/tejari.jpg",
            id: "1",
            title: "نگهداری انواع کالاهای تجاری",
            content: "اگر تولید کننده هستید و برای مدتی می خواهید محصولات خود را در انباری امن و ارزان نگهداری کنید ما می توانیم انواع کالا های تجاری شما را در انبار های زنجیره ای آرتا نگهداری کنیم"
        },
        {
            image: "/assets/Images/Services/shipping.jpg",
            id: "1",
            title: "حمل و نقل و باربری کالا به انبار",
            content: "شما می توانید با بهره گیری از یگان حمل و نقل ما اثاثیه خود را با بالاترین سرعت و کمترین هزینه از محل خود به انبار های ما یا از محل انبار ها به تمام نقاط استان یا کشور انتقال دهید"
        }
    ];
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        className: "flex flex-col justify-center items-center py-10 w-full relative mt-10 gap-10 px-5 ",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: `w-full lg:w-[70%] text-center font-bold text-3xl lg:text-4xl font-Yekan border-b-2 border-b-primary pb-5`,
                children: "خدمات تخصصی انبارهای عمومی آرتا"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "grid lg:grid-cols-3 grid-cols-1 md:grid-cols-2 gap-2 md:gap-6 max-w-[1270px] overflow-hidden",
                children: popularCategories.map((item)=>{
                    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "relative rounded-lg overflow-hidden  bg-white shadow-xl",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                alt: item.title,
                                src: item.image,
                                width: 0,
                                height: 0,
                                sizes: "100vw",
                                className: "w-full h-auto z-[1] hover:scale-110 transition-all duration-400"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex flex-col gap-4 mt-6 px-5 pb-5",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h3", {
                                        className: "text-[2rem] text-[#495057]",
                                        children: [
                                            item.title,
                                            " "
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "text-[1.3rem] text-[#adb5bd] text-justify",
                                        children: item.content
                                    })
                                ]
                            })
                        ]
                    }, item.id);
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(BigButton, {
                minWidth: true
            })
        ]
    });
}

// EXTERNAL MODULE: ./Components/Home/Slider.tsx
var Slider = __webpack_require__(4293);
;// CONCATENATED MODULE: ./Components/Home/IntroSlider.tsx



const IntroSlider = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        className: "w-full max-w-[1200px] md:grid md:grid-cols-2 flex flex-col-reverse gap-6 justify-between mx-auto px-5 mt-10",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex gap-10 flex-col",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                        className: "text-4xl text-[#495057]",
                        children: "بی نظیر ترین مجموعه انبار عمومی در ایران"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "text-xl text-[#adb5bd] text-justify ",
                        children: "هزینه نازل، کیفیت خدمات دهی بالا و امنیت عالی کالاهای انبار شده از مهمترین شاخص ها در نزد مشتریان برای انتخاب ما میباشد.حال پس از تجربه ای طولانی و موفقیت آمیز در بحث انبارداری آمادگی خود را در جهت ارایه خدمات بیشتر و بهتر بدین شرح تقدیم حضور می نماییم."
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                        className: "text-xl text-[#adb5bd] text-center",
                        children: "تماس فوری با کارشناسان ما : 91031682-021"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Slider/* Sliders */.E, {
                items: [
                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        src: "/assets/Images/slider/slider-1.jpg",
                        alt: "slider-1",
                        width: 0,
                        height: 0,
                        sizes: "100vw",
                        className: "w-full h-auto"
                    }, "slide-1"),
                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        src: "/assets/Images/slider/slider-2.jpg",
                        alt: "slider-1",
                        width: 0,
                        height: 0,
                        sizes: "100vw",
                        className: "w-full h-auto"
                    }, "slide-2"),
                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        src: "/assets/Images/slider/slider-3.jpg",
                        alt: "slider-1",
                        width: 0,
                        height: 0,
                        sizes: "100vw",
                        className: "w-full h-auto"
                    }, "slide-3")
                ]
            })
        ]
    });
};

;// CONCATENATED MODULE: ./Components/Home/Security.tsx


const Security = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        className: "w-full max-w-[1200px] md:grid md:grid-cols-2 flex flex-col gap-6 justify-between mx-auto px-5 mt-10",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                src: "/assets/Images/security.jpg",
                alt: "arta co security",
                width: 0,
                height: 0,
                sizes: "100vw",
                className: "w-full h-auto"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex flex-col gap-10 ",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                        className: "text-[2.5rem] text-[#495057]",
                        children: "تیم حفاظتی و امنیتی مستقر در انبارهای آرتا"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "text-[1.3rem] text-[#adb5bd] text-justify",
                        children: "تیم حفاظتی و امنیتی مستقر در انبارهای زنجیره ای آرتا زیر نظر نیروی انتظامی جمهوری اسلامی ایران به صورت 24 ساعته محافظ اموال و امنیت کالای شما در انبارهای آرتا می باشد."
                    })
                ]
            })
        ]
    });
};

// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/react.shared-subset.js
var react_shared_subset = __webpack_require__(2947);
;// CONCATENATED MODULE: ./Components/Home/AnbarTypes.tsx




function AnbarTypes() {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        className: "w-full max-w-[1200px] flex flex-col gap-7 mx-auto mt-10",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                className: "text-[2.4rem] text-[#495057]",
                children: "انواع انبارهای عمومی آرتا"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                className: "text-[1.3rem] text-[#adb5bd]",
                children: "انبار ها با توجه به کاربردهایی که برای مشتریان دارند از انواع مختلفی برخوردار هستند که در ادامه به برخی از این انبارها اشاره خواهیم نمود."
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex flex-col md:flex-row justify-between items-center gap-4 md:gap-0",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex flex-row gap-2",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                src: "/assets/Images/icons/png3.png",
                                alt: "icon",
                                width: 80,
                                height: 80
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex flex-col gap-3",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        className: "text-[#495057] text-[1.7rem]",
                                        children: "انبار کانتینری"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "text-[#495057] text-[1rem]",
                                        children: "اجاره انبار های کانتینری برای کالا"
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex flex-row gap-2",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                src: "/assets/Images/icons/png1.png",
                                alt: "icon",
                                width: 80,
                                height: 80
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex flex-col gap-3",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        className: "text-[#495057] text-[1.7rem]",
                                        children: "انبار های سردخانه ای"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "text-[#495057] text-[1rem]",
                                        children: "اجاره انبارهای روباز و سردخانه ای"
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex flex-row gap-2",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                src: "/assets/Images/icons/png2.png",
                                alt: "icon",
                                width: 80,
                                height: 80
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex flex-col gap-3",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        className: "text-[#495057] text-[1.7rem]",
                                        children: "انبار سوله ای مسقف"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "text-[#495057] text-[1rem]",
                                        children: "اجاره انواع انبار سوله ای"
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Slider/* Sliders */.E, {
                items: [
                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        src: "/assets/Images/slider/slider-1.jpg",
                        alt: "slider-1",
                        width: 0,
                        height: 0,
                        sizes: "100vw",
                        className: "w-auto h-auto max-h-[499px] overflow-hidden mx-auto"
                    }, "slide-1"),
                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        src: "/assets/Images/slider/slider-2.jpg",
                        alt: "slider-1",
                        width: 0,
                        height: 0,
                        sizes: "100vw",
                        className: "w-auto h-auto max-h-[499px] overflow-hidden mx-auto"
                    }, "slide-2"),
                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        src: "/assets/Images/slider/slider-3.jpg",
                        alt: "slider-1",
                        width: 0,
                        height: 0,
                        sizes: "100vw",
                        className: "w-auto h-auto max-h-[499px] overflow-hidden mx-auto"
                    }, "slide-3")
                ]
            })
        ]
    });
}
/* harmony default export */ const Home_AnbarTypes = (AnbarTypes);

// EXTERNAL MODULE: ./node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js
var module_proxy = __webpack_require__(1363);
;// CONCATENATED MODULE: ./Components/Home/DisclosureFeatures.tsx

const proxy = (0,module_proxy.createProxy)(String.raw`E:\anbareomomi\Components\Home\DisclosureFeatures.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const DisclosureFeatures = (__default__);
;// CONCATENATED MODULE: ./Components/Home/Features.tsx



function Features() {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        className: " mx-auto w-full max-w-[1200px] mt-10 pb-10",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                className: "text-[2.5rem] text-[#495057] w-full text-center",
                children: "برخی از ویژگی های آرتا"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex flex-col gap-6 md:grid md:grid-cols-2 mt-3",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(DisclosureFeatures, {}),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "grid grid-cols-2 gap-6 items-start h-fit",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "text-2xl text-[#495057] flex flex-row gap-2 items-center",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                        className: "fi fi-rr-credit-card flex items-center"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        children: "عضو رسمی اتحادیه"
                                    })
                                ]
                            }),
                            " ",
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "text-2xl text-[#495057] flex flex-row gap-2 items-center",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                        className: "fi fi-rr-credit-card flex items-center"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        children: "تحت پوشش بیمه ایران"
                                    })
                                ]
                            }),
                            " ",
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "text-2xl text-[#495057] flex flex-row gap-2 items-center",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                        className: "fi fi-rr-calendar-day flex items-center"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        children: "ربع قرن سابقه"
                                    })
                                ]
                            }),
                            " ",
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "text-2xl text-[#495057] flex flex-row gap-2 items-center",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                        className: "fi fi-rr-camera-cctv flex items-center"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        children: "دوربین مدار بسته"
                                    })
                                ]
                            }),
                            " ",
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "text-2xl text-[#495057] flex flex-row gap-2 items-center",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                        className: "fi fi-rr-bank flex items-center"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        children: "تحت ضمانت بانک پارسیان"
                                    })
                                ]
                            }),
                            " ",
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "text-2xl text-[#495057] flex flex-row gap-2 items-center",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                        className: "fi fi-rr-shield-check flex items-center"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        children: "ضد زلزله , آتش سوزی و سرقت"
                                    })
                                ]
                            })
                        ]
                    })
                ]
            })
        ]
    });
}
/* harmony default export */ const Home_Features = (Features);

;// CONCATENATED MODULE: ./app/page.tsx







async function Home() {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("main", {
        className: "bg-gray-100",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(Hero, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(TopCategories, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(IntroSlider, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(Security, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(Home_AnbarTypes, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(Home_Features, {})
        ]
    });
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [587,60,91,70], () => (__webpack_exec__(1853)));
module.exports = __webpack_exports__;

})();