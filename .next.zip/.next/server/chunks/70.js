exports.id = 70;
exports.ids = [70];
exports.modules = {

/***/ 7913:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 9053));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 3380, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 954, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 9857))

/***/ }),

/***/ 3113:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 1232, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 2987, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 831, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 6926, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 4282, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 6505, 23))

/***/ }),

/***/ 9857:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Sliders: () => (/* binding */ Sliders)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_alice_carousel__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4816);
/* harmony import */ var react_alice_carousel__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_alice_carousel__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_alice_carousel_lib_alice_carousel_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7556);
/* harmony import */ var react_alice_carousel_lib_alice_carousel_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_alice_carousel_lib_alice_carousel_css__WEBPACK_IMPORTED_MODULE_2__);
/* __next_internal_client_entry_do_not_use__ Sliders auto */ 


// import styles from "../styles/Responsive.module.css";
function Sliders({ items }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_alice_carousel__WEBPACK_IMPORTED_MODULE_1___default()), {
        items: items,
        infinite: true,
        mouseTracking: true,
        touchTracking: true,
        autoPlay: true,
        autoPlayInterval: 6000,
        disableButtonsControls: true
    });
}


/***/ }),

/***/ 9053:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ NavBar)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2451);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1440);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_navigation__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7114);
/* harmony import */ var next_navigation__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_navigation__WEBPACK_IMPORTED_MODULE_4__);
/* __next_internal_client_entry_do_not_use__ default auto */ 




function NavBar() {
    const router = (0,next_navigation__WEBPACK_IMPORTED_MODULE_4__.usePathname)();
    const [toggle, setToggle] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false);
    const houseplantsMenu = (0,react__WEBPACK_IMPORTED_MODULE_3__.useRef)();
    const potsMenu = (0,react__WEBPACK_IMPORTED_MODULE_3__.useRef)();
    const CareMenu = (0,react__WEBPACK_IMPORTED_MODULE_3__.useRef)();
    const AccessoriesMenu = (0,react__WEBPACK_IMPORTED_MODULE_3__.useRef)();
    let currentOpenedMenu;
    let currentMenuButton;
    const CloseMenu = ()=>{
        if (currentMenuButton) {
            currentMenuButton.classList.remove("underline", "text-gray-500");
            currentMenuButton = null;
        }
        if (currentOpenedMenu) {
            currentOpenedMenu.current.classList.remove("opacity-100", "pointer-events-auto");
            currentOpenedMenu.current.classList.add("opacity-0", "pointer-events-none");
            currentOpenedMenu = null;
        }
    };
    const OpenMenu = (menu, button)=>{
        if (currentMenuButton) {
            currentMenuButton.classList.remove("underline", "text-gray-500");
            if (currentMenuButton.id === button.id) {
                currentMenuButton = null;
            } else {
                currentMenuButton = button;
                button.classList.add("underline", "text-gray-500");
            }
        } else {
            button.classList.add("underline", "text-gray-500");
            currentMenuButton = button;
        }
        if (currentOpenedMenu) {
            currentOpenedMenu.current.classList.add("opacity-0", "pointer-events-none");
            currentOpenedMenu.current.classList.remove("opacity-100", "pointer-events-auto");
            if (currentOpenedMenu === menu) {
                currentOpenedMenu = null;
                return;
            }
            currentOpenedMenu = null;
        }
        menu.current.classList.remove("opacity-0", "pointer-events-none");
        menu.current.classList.add("pointer-events-auto", "opacity-100");
        currentOpenedMenu = menu;
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "fixed top-0 w-full bg-[#343a40] z-10 text-white",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("nav", {
                className: `md:py-4 relative h-auto flex py-4 transition-all px-4 items-center justify-between  max-w-[1200px] mx-auto flex-col lg:flex-row`,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                        src: "/assets/Images/arta-white.png",
                        alt: "logo",
                        width: 263,
                        height: 80
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "flex flex-col md:flex-row justify-center gap-6 items-start md:items-center",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                            href: "tel:+982191031682",
                            className: "bg-gray-500 px-3 py-2 rounded-md flex items-center gap-3 hover:text-[#c96b1e] transition-all",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    children: "021-91031682"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                    className: "fi fi-rr-phone-call flex items-center"
                                }),
                                " "
                            ]
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex absolute top-[100%] w-full bg-white px-14 py-10 flex-row justify-evenly gap-10 duration-400 opacity-0 transition-all pointer-events-none",
                        ref: houseplantsMenu,
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "flex flex-wrap gap-10"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                                    src: "/assets/Images/navbar/nav-1.jpg",
                                    alt: "HousePlants",
                                    width: 0,
                                    height: 0,
                                    sizes: "100%",
                                    className: "w-auto h-auto min-w-[335px]"
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex absolute top-[100%] w-full bg-white px-14 py-10 flex-row justify-evenly gap-10 duration-400 opacity-0 transition-all pointer-events-none",
                        ref: potsMenu,
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "flex flex-wrap gap-10"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                                    src: "/assets/Images/navbar/nav-2.jpg",
                                    alt: "Pots",
                                    width: 0,
                                    height: 0,
                                    sizes: "100%",
                                    className: "w-auto h-auto min-w-[335px]"
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex absolute top-[100%] w-full bg-white px-14 py-10 flex-row justify-evenly gap-10 duration-400 opacity-0 transition-all pointer-events-none",
                        ref: CareMenu,
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "flex flex-wrap gap-10"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                                    src: "/assets/Images/navbar/nav-3.jpg",
                                    alt: "Pots",
                                    width: 0,
                                    height: 0,
                                    sizes: "100%",
                                    className: "w-auto h-auto min-w-[335px]"
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex absolute top-[100%] w-full bg-white px-14 py-10 flex-row justify-evenly gap-10 duration-400 opacity-0 transition-all pointer-events-none",
                        ref: AccessoriesMenu,
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "flex flex-wrap gap-10"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                                    src: "/assets/Images/navbar/nav-4.jpg",
                                    alt: "Pots",
                                    width: 0,
                                    height: 0,
                                    sizes: "100%",
                                    className: "w-auto h-auto min-w-[335px]"
                                })
                            })
                        ]
                    })
                ]
            })
        })
    });
}


/***/ }),

/***/ 4293:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   E: () => (/* binding */ e0)
/* harmony export */ });
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1363);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`E:\anbareomomi\Components\Home\Slider.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;

const e0 = proxy["Sliders"];


/***/ }),

/***/ 7547:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ RootLayout)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
// EXTERNAL MODULE: ./node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js
var module_proxy = __webpack_require__(1363);
;// CONCATENATED MODULE: ./Components/Shared/NavBar.tsx

const proxy = (0,module_proxy.createProxy)(String.raw`E:\anbareomomi\Components\Shared\NavBar.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const NavBar = (__default__);
// EXTERNAL MODULE: ./app/globals.css
var globals = __webpack_require__(7272);
// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/react.shared-subset.js
var react_shared_subset = __webpack_require__(2947);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(4178);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(5124);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./Components/Home/Slider.tsx
var Slider = __webpack_require__(4293);
;// CONCATENATED MODULE: ./Components/Shared/Footer.tsx





function Footer() {
    const mapItems = [
        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "flex flex-col gap-2 items-center",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                    href: "https://maps.google.com/maps?ll=35.675028,51.232624&z=16&t=m&hl=en&gl=US&mapclient=embed",
                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        src: "/assets/Images/slider/map-1.png",
                        alt: "tehran central office location",
                        width: 300,
                        height: 0,
                        className: "h-auto"
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                    children: "شعبه مرکزی تهران"
                })
            ]
        }, "map-1"),
        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "flex flex-col gap-2 items-center",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                    href: "https://maps.google.com/maps?ll=35.697111,51.196917&z=16&t=m&hl=en&gl=US&mapclient=embed",
                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        src: "/assets/Images/slider/map-2.png",
                        alt: "tehran central office location",
                        width: 300,
                        height: 0,
                        className: "h-auto"
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                    children: "شعبه دوم تهران"
                })
            ]
        }, "map-2"),
        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "flex flex-col gap-2 items-center",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                    href: "https://maps.google.com/maps?ll=35.699212,50.317933&z=16&t=m&hl=en&gl=US&mapclient=embed",
                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        src: "/assets/Images/slider/map-3.png",
                        alt: "tehran central office location",
                        width: 300,
                        height: 0,
                        className: "h-auto"
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                    children: "شعبه سوم کرج ( اشتهارد)"
                })
            ]
        }, "map-3"),
        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "flex flex-col gap-2 items-center",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                    href: "https://maps.google.com/maps?ll=35.688386,51.185848&z=16&t=m&hl=en&gl=US&mapclient=embed",
                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        src: "/assets/Images/slider/map-4.png",
                        alt: "tehran central office location",
                        width: 300,
                        height: 0,
                        className: "h-auto"
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                    children: "شعبه چهارم ( سه راه شهریار)"
                })
            ]
        }, "map-4")
    ];
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        className: "bg-gray-500 w-full py-14 px-10 text-white",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "flex flex-col md:grid md:grid-cols-2 justify-between max-w-[1200px] w-full mx-auto",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "flex flex-col gap-5 justify-center items-center flex-grow",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            src: "/assets/Images/arta-white.png",
                            alt: "logo",
                            width: 263,
                            height: 80
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "text-xl",
                            children: "جهت اطلاع از هزینه ها و خدمات آرتا با ۰۲۱۹۱۰۳۱۶۸۲ تماس حاصل نمایید"
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(Slider/* Sliders */.E, {
                    items: mapItems
                })
            ]
        })
    });
}
/* harmony default export */ const Shared_Footer = (Footer);

;// CONCATENATED MODULE: ./app/layout.tsx





async function RootLayout({ children, params }) {
    const { lang } = params;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("head", {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("title", {
                        children: "آرتا بازرگان"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "description",
                        content: "انبارهای عمومی | انبارهای زنجیره ای آرتا | خرید و فروش کانتینر ، اجاره سوله و سردخانه و انبار تجاری و وسایل منزل با بیش از ربع قرن تجربه"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("html", {
                lang: lang,
                dir: "rtl",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("body", {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(NavBar, {}),
                        /*#__PURE__*/ jsx_runtime_.jsx("main", {
                            className: "mt-[150px] md:mt-[113px] relative",
                            children: children
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(Shared_Footer, {})
                    ]
                })
            })
        ]
    });
}


/***/ }),

/***/ 7481:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85);
/* harmony import */ var next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__);
  

  /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((props) => {
    const imageData = {"type":"image/x-icon","sizes":"256x256"}
    const imageUrl = (0,next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__.fillMetadataSegment)(".", props.params, "favicon.ico")

    return [{
      ...imageData,
      url: imageUrl + "",
    }]
  });

/***/ }),

/***/ 7272:
/***/ (() => {



/***/ })

};
;